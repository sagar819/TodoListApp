﻿using Moq;
using Xunit;
using TodoList.Models;
using TodoList.Services;

namespace TodoList.Tests
{
    public class TodoServiceTests
    {
        
        private readonly ITodoService _todoService;

        public TodoServiceTests()
        {
            _todoService = new TodoService();
        }

        [Fact]
        public void GetAll_EmptyList_ReturnsEmptyCollection()
        {
            // Act
            var result = _todoService.GetAll();

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public void GetAll_WithItems_ReturnsAllItems()
        {
            // Arrange
            var todo1 = new TodoItem { Name = "Task 1", Priority = 1, Status = TodoStatus.NotStarted };
            var todo2 = new TodoItem { Name = "Task 2", Priority = 2, Status = TodoStatus.InProgress };
            _todoService.Add(todo1);
            _todoService.Add(todo2);

            // Act
            var result = _todoService.GetAll();

            // Assert
            Assert.Equal(2, result.Count());
            Assert.Contains(result, item => item.Name == "Task 1");
            Assert.Contains(result, item => item.Name == "Task 2");
        }

        [Fact]
        public void GetById_ExistingId_ReturnsTodoItem()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1, Status = TodoStatus.NotStarted };
            _todoService.Add(todo);

            // Act
            var result = _todoService.GetById(todo.Id);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Task 1", result.Name);
        }

        [Fact]
        public void GetById_NonExistingId_ReturnsNull()
        {
            // Act
            var result = _todoService.GetById(999);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void Add_ValidTodoItem_AddsToCollection()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1, Status = TodoStatus.NotStarted };

            // Act
            _todoService.Add(todo);

            // Assert
            var result = _todoService.GetAll();
            Assert.Single(result);
            Assert.Equal("Task 1", result.First().Name);
            Assert.NotEqual(0, result.First().Id); // Verifies ID was assigned
        }

        [Fact]
        public void Update_ExistingTodoItem_UpdatesProperties()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1, Status = TodoStatus.NotStarted };
            _todoService.Add(todo);

            // Act
            todo.Name = "Updated Task";
            todo.Priority = 2;
            todo.Status = TodoStatus.InProgress;
            _todoService.Update(todo);

            // Assert
            var updatedTodo = _todoService.GetById(todo.Id);
            Assert.Equal("Updated Task", updatedTodo.Name);
            Assert.Equal(2, updatedTodo.Priority);
            Assert.Equal(TodoStatus.InProgress, updatedTodo.Status);
        }

        [Fact]
        public void Update_NonExistingTodoItem_DoesNothing()
        {
            // Arrange
            var todo = new TodoItem { Id = 999, Name = "Non-existing Task" };

            // Act
            _todoService.Update(todo);

            // Assert
            var result = _todoService.GetAll();
            Assert.Empty(result);
        }

        [Fact]
        public void Delete_CompletedTodoItem_RemovesFromCollection()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1, Status = TodoStatus.Completed };
            _todoService.Add(todo);

            // Act
            _todoService.Delete(todo.Id);

            // Assert
            var result = _todoService.GetAll();
            Assert.Empty(result);
        }

        [Fact]
        public void Delete_NonCompletedTodoItem_DoesNotRemoveFromCollection()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1, Status = TodoStatus.InProgress };
            _todoService.Add(todo);

            // Act
            _todoService.Delete(todo.Id);

            // Assert
            var result = _todoService.GetAll();
            Assert.Single(result);
        }

        [Fact]
        public void Delete_NonExistingId_DoesNothing()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1, Status = TodoStatus.Completed };
            _todoService.Add(todo);

            // Act
            _todoService.Delete(999);

            // Assert
            var result = _todoService.GetAll();
            Assert.Single(result);
        }

        [Fact]
        public void IsNameUnique_UniqueNameNewItem_ReturnsTrue()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1 };
            _todoService.Add(todo);

            // Act
            var result = _todoService.IsNameUnique("Task 2", null);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void IsNameUnique_DuplicateNameNewItem_ReturnsFalse()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1 };
            _todoService.Add(todo);

            // Act
            var result = _todoService.IsNameUnique("Task 1", null);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void IsNameUnique_SameNameSameId_ReturnsTrue()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1 };
            _todoService.Add(todo);

            // Act
            var result = _todoService.IsNameUnique("Task 1", todo.Id);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void IsNameUnique_DuplicateNameDifferentId_ReturnsFalse()
        {
            // Arrange
            var todo1 = new TodoItem { Name = "Task 1", Priority = 1 };
            var todo2 = new TodoItem { Name = "Task 2", Priority = 1 };
            _todoService.Add(todo1);
            _todoService.Add(todo2);

            // Act
            var result = _todoService.IsNameUnique("Task 1", todo2.Id);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public void Add_MultipleTodoItems_AssignsUniqueIds()
        {
            // Arrange
            var todo1 = new TodoItem { Name = "Task 1", Priority = 1 };
            var todo2 = new TodoItem { Name = "Task 2", Priority = 2 };

            // Act
            _todoService.Add(todo1);
            _todoService.Add(todo2);

            // Assert
            Assert.NotEqual(todo1.Id, todo2.Id);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void IsNameUnique_EmptyOrNullName_ReturnsTrue(string name)
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1 };
            _todoService.Add(todo);

            // Act
            var result = _todoService.IsNameUnique(name, null);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void IsNameUnique_CaseInsensitiveDuplicateName_ReturnsFalse()
        {
            // Arrange
            var todo = new TodoItem { Name = "Task 1", Priority = 1 };
            _todoService.Add(todo);

            // Act
            var result = _todoService.IsNameUnique("TASK 1", null);

            // Assert
            Assert.False(result);
        }
    }
}