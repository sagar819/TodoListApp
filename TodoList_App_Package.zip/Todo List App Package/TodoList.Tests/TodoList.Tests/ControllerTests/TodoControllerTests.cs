﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using TodoList.Controllers;
using TodoList.Models;
using TodoList.Services;
using TodoList.ViewModels;
using Xunit;

namespace TodoList.Tests
{
    public class HomeControllerTests
    {
        private readonly Mock<ITodoService> _mockTodoService;
        private readonly HomeController _controller;

        public HomeControllerTests()
        {
            _mockTodoService = new Mock<ITodoService>();
            _controller = new HomeController(_mockTodoService.Object);
        }

        [Fact]
        public void Index_ReturnsViewResult()
        {
            // Act
            var result = _controller.Index();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void Create_ValidModel_RedirectsToIndex()
        {
            // Arrange
            string taskName = "Test Task";
            _mockTodoService.Setup(x => x.IsNameUnique(taskName, null)).Returns(true);

            var todoViewModel = new TodoViewModel
            {
                Name = taskName,
                Priority = 1,
                Status = TodoStatus.NotStarted
            };

            // Act
            var result = _controller.Create(todoViewModel);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectResult.ActionName);
        }

        [Fact]
        public void Create_InvalidModel_ReturnsView()
        {
            // Arrange
            string taskName = "";
            _mockTodoService.Setup(x => x.IsNameUnique(taskName, null)).Returns(false);

            var todoViewModel = new TodoViewModel
            {
                Name = taskName,
                Priority = 1,
                Status = TodoStatus.NotStarted
            };

            _controller.ModelState.AddModelError("Name", "Name is required");

            // Act
            var result = _controller.Create(todoViewModel);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Same(todoViewModel, viewResult.Model);
        }

        [Fact]
        public void Create_DuplicateName_ReturnsViewWithError()
        {
            // Arrange
            string taskName = "Existing Task";
            _mockTodoService.Setup(x => x.IsNameUnique(taskName, null)).Returns(false);

            var todoViewModel = new TodoViewModel
            {
                Name = taskName,
                Priority = 1,
                Status = TodoStatus.NotStarted
            };

            // Act
            var result = _controller.Create(todoViewModel);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Same(todoViewModel, viewResult.Model);
            Assert.True(_controller.ModelState.ContainsKey("Name"));
        }
    }
}