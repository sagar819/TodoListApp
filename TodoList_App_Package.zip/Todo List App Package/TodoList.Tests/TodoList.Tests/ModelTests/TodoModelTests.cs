﻿using System.ComponentModel.DataAnnotations;
using TodoList.Models;
using Xunit;
using System.Collections.Generic;

namespace TodoList.Tests.ModelTests
{
    public class TodoModelTests
    {
        [Fact]
        public void Todo_WithValidData_PassesValidation()
        {
            // Arrange
            var todoItem = new TodoItem
            {
                Name = "Valid Task",
                Priority = 1,
                Status = TodoStatus.NotStarted
            };

            // Act
            var validationResults = ValidateModel(todoItem);

            // Assert
            Assert.Empty(validationResults);
        }

        [Fact]
        public void Todo_WithEmptyName_FailsValidation()
        {
            // Arrange
            var todoItem = new TodoItem
            {
                Name = string.Empty,
                Priority = 1,
                Status = TodoStatus.NotStarted
            };

            // Act
            var validationContext = new ValidationContext(todoItem);
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(todoItem, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            var validationResult = Assert.Single(validationResults);
            Assert.Equal("Task name is required", validationResult.ErrorMessage);
            Assert.Contains("Name", validationResult.MemberNames);
        }

        [Theory]
        [InlineData("")]
        [InlineData(" ")]
        [InlineData(null)]
        public void Todo_WithInvalidName_FailsValidation(string invalidName)
        {
            // Arrange
            var todoItem = new TodoItem
            {
                Name = invalidName,
                Priority = 1,
                Status = TodoStatus.NotStarted
            };

            // Act
            var validationContext = new ValidationContext(todoItem);
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(todoItem, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Contains(validationResults, vr => vr.MemberNames.Contains("Name"));
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Todo_WithInvalidPriority_FailsValidation(int invalidPriority)
        {
            // Arrange
            var todoItem = new TodoItem
            {
                Name = "Valid Task",
                Priority = invalidPriority,
                Status = TodoStatus.NotStarted
            };

            // Act
            var validationContext = new ValidationContext(todoItem);
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(todoItem, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            var validationResult = Assert.Single(validationResults);
            Assert.Equal("Priority must be a positive number", validationResult.ErrorMessage);
            Assert.Contains("Priority", validationResult.MemberNames);
        }

        [Theory]
        [InlineData("Valid Task", 1, TodoStatus.NotStarted)]
        [InlineData("Another Task", 2, TodoStatus.InProgress)]
        [InlineData("Completed Task", 3, TodoStatus.Completed)]
        public void Todo_WithValidData_PassesValidation_Theory(string name, int priority, TodoStatus status)
        {
            // Arrange
            var todoItem = new TodoItem
            {
                Name = name,
                Priority = priority,
                Status = status
            };

            // Act
            var validationContext = new ValidationContext(todoItem);
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(todoItem, validationContext, validationResults, true);

            // Assert
            Assert.True(isValid);
            Assert.Empty(validationResults);
        }

        [Fact]
        public void Todo_WithMultipleValidationErrors_ReturnsAllErrors()
        {
            // Arrange
            var todoItem = new TodoItem
            {
                Name = string.Empty,
                Priority = 0,
                Status = TodoStatus.NotStarted
            };

            // Act
            var validationContext = new ValidationContext(todoItem);
            var validationResults = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(todoItem, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Equal(2, validationResults.Count);
            Assert.Contains(validationResults, vr => vr.MemberNames.Contains("Name"));
            Assert.Contains(validationResults, vr => vr.MemberNames.Contains("Priority"));
        }

        private IEnumerable<ValidationResult> ValidateModel(object model)
        {
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(model);
            Validator.TryValidateObject(model, validationContext, validationResults, true);
            return validationResults;
        }
    }
}