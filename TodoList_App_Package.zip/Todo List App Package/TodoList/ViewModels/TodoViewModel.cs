﻿using System.ComponentModel.DataAnnotations;
using TodoList.Models;

namespace TodoList.ViewModels
{
    public class TodoViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Task name is required")]
        [StringLength(200, ErrorMessage = "Task name cannot exceed 200 characters")]
        [Display(Name = "Task Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Priority is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Priority must be a positive number")]
        public int Priority { get; set; }

        [Required(ErrorMessage = "Status is required")]
        [Display(Name = "Status")]
        public TodoStatus Status { get; set; }
    }
}
