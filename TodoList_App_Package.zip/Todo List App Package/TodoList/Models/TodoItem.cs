﻿using System.ComponentModel.DataAnnotations;

namespace TodoList.Models
{
    public class TodoItem
    {
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Task name is required")]
        [StringLength(200, ErrorMessage = "Task name cannot exceed 200 characters")]
        public string Name { get; set; }
        
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Priority must be a positive number")]
        public int Priority { get; set; }
        public TodoStatus Status { get; set; }
    }

    public enum TodoStatus
    {
        NotStarted,
        InProgress,
        Completed
    }
}
