# Todo List Application

A single-page Todo List application built with ASP.NET Core MVC that allows users to manage their tasks effectively.

## Features

- Create, Read, Update, and Delete tasks
- Task prioritization
- Status tracking (Not Started, In Progress, Completed)
- Validation rules enforcement
- Clean and responsive UI
- In-memory data storage

```

The application will be available at `https://localhost:####` 

### Project Structure

```
TodoList/
├── Controllers/
│   └── HomeController.cs
├── Models/
│   ├── TodoItem.cs
│   
├── Services/
│   ├── ITodoService.cs
│   └── TodoService.cs
├── ViewModels/
│   └── TodoViewModel.cs
├── Views/
│   └── Home/
│       ├── Index.cshtml
│       ├── Create.cshtml
│       └── Edit.cshtml
└── Tests/
    ├── Controllers/
    ├── Models/
    └── Services/
```

## Features in Detail

### Task Management
- Create new tasks with name and priority
- Edit existing tasks
- Delete completed tasks only
- View all tasks in a list format

### Validation Rules
1. Task Name
   - Required field
   - Maximum length: 200 characters
   - Must be unique across all tasks

2. Priority
   - Required field
   - Must be a positive number

3. Status
   - Options: Not Started, In Progress, Completed
   - Only completed tasks can be deleted


### Technologies Used
- ASP.NET Core 6.0
- C#
- Razor Views
- Bootstrap for UI
- xUnit for testing
- Moq for mocking in tests

### Testing
The solution includes comprehensive unit tests for:
- Controllers
- Services
- Models
- Validation rules


## Development Notes

### Adding a New Task

var task = new TodoItem
{
    Name = "Task Name",
    Priority = 1,
    Status = TodoStatus.NotStarted
};
_todoService.Add(task);


### Validation Example
Model validation
[Required(ErrorMessage = "Task name is required")]
[StringLength(200, ErrorMessage = "Task name cannot exceed 200 characters")]
public string Name { get; set; }


### Service Layer Example

public bool IsNameUnique(string name, int? id)
{
    return !_todos.Any(t => t.Name.Equals(name, StringComparison.OrdinalIgnoreCase) 
                        && (!id.HasValue || t.Id != id.Value));
}


```