﻿using TodoList.Models;

namespace TodoList.Services
{
    public class TodoService : ITodoService
    {
        private readonly List<TodoItem> _todos;
        private int _nextId = 1;

        public TodoService()
        {
            _todos = new List<TodoItem>();
        }

        public List<TodoItem> GetAll()
        {
            return _todos.ToList();
        }

        public TodoItem GetById(int id)
        {
            return _todos.FirstOrDefault(t => t.Id == id);
        }

        public void Add(TodoItem item)
        {
            item.Id = _nextId++;
            _todos.Add(item);
        }

        public void Update(TodoItem item)
        {
            var existingItem = _todos.FirstOrDefault(t => t.Id == item.Id);
            if (existingItem != null)
            {
                existingItem.Name = item.Name;
                existingItem.Priority = item.Priority;
                existingItem.Status = item.Status;
            }
        }

        public void Delete(int id)
        {
            var item = _todos.FirstOrDefault(t => t.Id == id);
            if (item != null && item.Status == TodoStatus.Completed)
            {
                _todos.Remove(item);
            }
        }

        public bool IsNameUnique(string name, int? id = null)
        {
            return !_todos.Any(t => t.Name.Equals(name, StringComparison.OrdinalIgnoreCase)
                                   && (!id.HasValue || t.Id != id.Value));
        }
    }

}
