﻿using TodoList.Models;

namespace TodoList.Services
{
    public interface ITodoService
    {
        List<TodoItem> GetAll();
        TodoItem GetById(int id);
        void Add(TodoItem item);
        void Update(TodoItem item);
        void Delete(int id);
        bool IsNameUnique(string name, int? id = null);
    }
}
