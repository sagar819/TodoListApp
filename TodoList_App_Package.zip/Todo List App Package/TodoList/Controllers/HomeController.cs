using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TodoList.Models;
using TodoList.Services;
using TodoList.ViewModels;

namespace TodoList.Controllers
{
    public class HomeController : Controller
    {
        private readonly ITodoService _todoService;

        public HomeController(ITodoService todoService)
        {
            _todoService = todoService;
        }

        public IActionResult Index()
        {
            var todos = _todoService.GetAll();
            return View(todos);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new TodoViewModel());
        }

        [HttpPost]
        public IActionResult Create(TodoViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (!_todoService.IsNameUnique(model.Name))
            {
                ModelState.AddModelError("Name", "A task with this name already exists");
                return View(model);
            }

            var todo = new TodoItem
            {
                Name = model.Name,
                Priority = model.Priority,
                Status = model.Status
            };

            _todoService.Add(todo);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var todo = _todoService.GetById(id);
            if (todo == null)
                return NotFound();

            var viewModel = new TodoViewModel
            {
                Id = todo.Id,
                Name = todo.Name,
                Priority = todo.Priority,
                Status = todo.Status
            };

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Edit(TodoViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (!_todoService.IsNameUnique(model.Name, model.Id))
            {
                ModelState.AddModelError("Name", "A task with this name already exists");
                return View(model);
            }

            var todo = new TodoItem
            {
                Id = model.Id,
                Name = model.Name,
                Priority = model.Priority,
                Status = model.Status
            };

            _todoService.Update(todo);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            _todoService.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }

}
