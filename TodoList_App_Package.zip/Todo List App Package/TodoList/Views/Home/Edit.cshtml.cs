using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TodoList.Views.Home
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
